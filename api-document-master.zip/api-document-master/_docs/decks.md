FORMAT: 1A

## デッキ一覧 [/api/v1/decks]
### デッキ一覧 [GET]
### 処理概要

- デッキの一覧を返却する
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Request
    + Headers
            Content-Type: application/json

- Response 200 (application/json)
    - Attributes
        - data: (array)
            - (object)
                - id: 12000 (number)
                - deck_id: 1 (number)
                - name: 名前テキスト (string)
                + publish_status: 1 (number)


## デッキ詳細 [/api/v1/decks/{deck_id}]
### デッキ詳細 [GET]
### 処理概要

- デッキの詳細を返却する
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Parameters
    + deck_id: 1 (number) - デッキID（テーブルユニークID）

+ Request
    + Headers
            Content-Type: application/json

- Response 200 (application/json)
    - Attributes
        - data: (array)
            - (object)
                - id: 12000 (number)
                - deck_id: 1 (number)
                - name: 名前テキスト (string)
                - cards: (array)
                    - (object)
                        - id: 1 (number)
                        - card_id: 1 (number)
                        - name: `Venusaur-EX` (string)
                + publish_status: 1 (number)

## デッキ登録 [/api/v1/decks]
### デッキ登録 [POST]
### 処理概要

- デッキを1件新規登録する。
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

- Request (application/json)
    + Headers
        Content-Type: application/json
    - Attributes
        - name: `名前テキスト` (string)
        - cards: (array)
            - (object)
                - id: 1 (number)
                - card_id: 1 (number)
                - name: `Venusaur-EX` (string)

- Response 200 (application/json)
    - Attributes
        - result: 1 (number)
        - error_code: ` ` (string)
        - error_message: ` ` (string)


## デッキ編集 [/api/v1/decks/{deck_id}]
### デッキ編集 [PUT]
### 処理概要

- デッキを1件編集する。
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Parameters
    + deck_id: 1 (number) - デッキID（テーブルユニークID）

- Request (application/json)
    + Headers
        Content-Type: application/json
    - Attributes
      - name: `名前テキスト` (string)
      - cards: (array)
          - (object)
              - id: 1 (number)
              - card_id: 1 (number)
              - name: `Venusaur-EX` (string)

- Response 200 (application/json)
    - Attributes
        - result: 1 (number)
        - error_code: ` ` (string)
        - error_message: ` ` (string)


## デッキ削除 [/api/v1/decks/{deck_id}]
### デッキ削除 [DELETE]
### 処理概要

- デッキを1件削除する。

+ Parameters
    + deck_id: 1 (number) - デッキID（テーブルユニークID）

- Request (application/json)
    + Headers
        Content-Type: application/json

- Response 200 (application/json)
    - Attributes
        - result: 1 (number)
        - error_code: ` ` (string)
        - error_message: ` ` (string)
