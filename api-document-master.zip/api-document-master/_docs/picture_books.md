FORMAT: 1A

## ポケモン図鑑一覧 [/api/v1/picture_books{?search,publish_status,type,per_page,page,sort_column,sort,csv}]
+ Parameters
  + search: 'text' (string, optional) - 検索
  + publish_status: 1 (number, optional) -  Status
  + type: 1 (number, optional) -  Type
  + per_page: 10 (number, optional) -  1ページに表示する件数
  + page: 1 (number, optional) -  ページ番号
  + sort_column: "description" (number, optional) -  ソートするパラメータ
  + sort: "DESC" (number, optional) -  ASC or DESC
  + csv: true (number, optional) -  CSV用一覧取得

### ポケモン図鑑一覧 [GET]
### 処理概要

- ポケモン図鑑の一覧を返却する
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Request
    + Headers
          Authorization: Bearer eyJ0eXAiOi...
          Content-Type: application/json

- Response 200 (application/json)
    - Attributes
        - current_page: 2 (number)
        - first_page_url: `http://test-admin-api.ikp.jp/api/picture_books?page=1` (string)
        - from: 6 (number)
        - last_page": 2 (number)
        - last_page_url: `http://test-admin-api.ikp.jp/api/picture_books?page=2` (string)
        - next_page_url: null (string)
        - path: `http://test-admin-api.ikp.jp/api/picture_books` (string)
        - per_page: "5" (number)
        - prev_page_url: `http://test-admin-api.ikp.jp/api/picture_books?page=1` (string)
        - to: 10 (number)
        - total: 10 (number)
        - data: (array)
            - (object)
                - id: 12000 (number)
                - name: 名前テキスト (string)
                - type: 1 (number)
                - height: 100cm (string)
                - weight: 10kg (string)
                - number: 123 (string)
                - energy: 1 (string)
                - body: 詳細テキスト (string)
                - images: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAABQCAMAAACpg44GAAAABGdBTUEAALGP` (string)
                + publish_status: 1 (number)
                - created_at: `2018-11-08 16:39:55` (string)
                - updated_at: `2018-11-08 16:39:55` (string)
                - deleted_at: `2018-11-08 16:39:55` (string)


## ポケモン図鑑詳細 [/api/v1/picture_books/{picture_book_id}]
### ポケモン図鑑詳細 [GET]
### 処理概要

- ポケモン図鑑の詳細を返却する
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Parameters
    + picture_book_id: 1 (number) - ポケモン図鑑ID（テーブルユニークID）

+ Request
    + Headers
          Authorization: Bearer eyJ0eXAiOi...
          Content-Type: application/json

- Response 200 (application/json)
    - Attributes
        - id: 12000 (number)
        - name: 名前テキスト (string)
        - type: 1 (number)
        - height: 100cm (string)
        - weight: 10kg (string)
        - number: 123 (string)
        - energy: 1 (string)
        - body: 詳細テキスト (string)
        - images: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAABQCAMAAACpg44GAAAABGdBTUEAALGP` (string)
        + publish_status: 1 (number)
        - created_at: `2018-11-08 16:39:55` (string)
        - updated_at: `2018-11-08 16:39:55` (string)
        - deleted_at: `2018-11-08 16:39:55` (string)

## ポケモン図鑑登録 [/api/v1/picture_books]
### ポケモン図鑑登録 [POST]
### 処理概要

- ポケモン図鑑を1件新規登録する。
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

- Request (application/json)
    + Headers
          Authorization: Bearer eyJ0eXAiOi...
    - Attributes
        - name: 名前テキスト (string)
        - type: 1 (number)
        - height: 100cm (string)
        - weight: 10kg (string)
        - number: 123 (string)
        - energy: 1 (string)
        - body: 詳細テキスト (string)
        - images: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAABQCAMAAACpg44GAAAABGdBTUEAALGP` (string)
        + publish_status: 1 (number)

- Response 200 (application/json)
    - Attributes
        - id: 12000 (number)
        - name: 名前テキスト (string)
        - type: 1 (number)
        - height: 100cm (string)
        - weight: 10kg (string)
        - number: 123 (string)
        - energy: 1 (string)
        - body: 詳細テキスト (string)
        - images: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAABQCAMAAACpg44GAAAABGdBTUEAALGP` (string)
        + publish_status: 1 (number)
        - created_at: `2018-11-08 16:39:55` (string)
        - updated_at: `2018-11-08 16:39:55` (string)
        - deleted_at: `2018-11-08 16:39:55` (string)


## ポケモン図鑑編集 [/api/v1/picture_books/{picture_book_id}]
### ポケモン図鑑編集 [PUT]
### 処理概要

- ポケモン図鑑を1件編集する。
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Parameters
    + picture_book_id: 1 (number) - ポケモン図鑑ID（テーブルユニークID）

- Request (application/json)
    + Headers
          Authorization: Bearer eyJ0eXAiOi...
    - Attributes
        - name: 名前テキスト (string)
        - type: 1 (number)
        - height: 100cm (string)
        - weight: 10kg (string)
        - number: 123 (string)
        - energy: 1 (string)
        - body: 詳細テキスト (string)
        - images: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAABQCAMAAACpg44GAAAABGdBTUEAALGP` (string)
        + publish_status: 1 (number)
        - created_at: `2018-11-08 16:39:55` (string)
        - updated_at: `2018-11-08 16:39:55` (string)
        - deleted_at: `2018-11-08 16:39:55` (string)

- Response 200 (application/json)
    - Attributes
        - id: 12000 (number)
        - name: 名前テキスト (string)
        - type: 1 (number)
        - height: 100cm (string)
        - weight: 10kg (string)
        - number: 123 (string)
        - energy: 1 (string)
        - body: 詳細テキスト (string)
        - images: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAABQCAMAAACpg44GAAAABGdBTUEAALGP` (string)
        + publish_status: 1 (number)
        - created_at: `2018-11-08 16:39:55` (string)
        - updated_at: `2018-11-08 16:39:55` (string)
        - deleted_at: `2018-11-08 16:39:55` (string)
