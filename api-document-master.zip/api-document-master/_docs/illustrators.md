FORMAT: 1A

## illustrator一覧 [/api/v1/illustrators{?search,publish_status,per_page,page,sort_column,sort,csv}]
+ Parameters
  + search: 'text' (string, optional) - 検索
  + publish_status: 1 (number, optional) -  Status
  + per_page: 10 (number, optional) -  1ページに表示する件数
  + page: 1 (number, optional) -  ページ番号
  + sort_column: "description" (number, optional) -  ソートするパラメータ
  + sort: "DESC" (number, optional) -  ASC or DESC
  + csv: true (number, optional) -  CSV用一覧取得

### illustrator一覧 [GET]
### 処理概要

- illustratorの一覧を返却する
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Request
    + Headers
          Authorization: Bearer eyJ0eXAiOi...
          Content-Type: application/json

- Response 200 (application/json)
    - Attributes
        - current_page: 2 (number)
        - first_page_url: `http://test-admin-api.ikp.jp/api/illustrators?page=1` (string)
        - from: 6 (number)
        - last_page": 2 (number)
        - last_page_url: `http://test-admin-api.ikp.jp/api/illustrators?page=2` (string)
        - next_page_url: null (string)
        - path: `http://test-admin-api.ikp.jp/api/illustrators` (string)
        - per_page: "5" (number)
        - prev_page_url: `http://test-admin-api.ikp.jp/api/illustrators?page=1` (string)
        - to: 10 (number)
        - total: 10 (number)
        - data: (array)
            - (object)
                - id: 12000 (number)
                - name: 名前テキスト (string)
                - description: メモ (string)
                + publish_status: 1 (number)
                - created_at: `2018-11-08 16:39:55` (string)
                - updated_at: `2018-11-08 16:39:55` (string)
                - deleted_at: `2018-11-08 16:39:55` (string)

## illustrator詳細 [/api/v1/illustrators/{illustrator_id}]
### illustrator詳細 [GET]
### 処理概要

- illustratorの詳細を返却する
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Parameters
    + illustrator_id: 1 (number) - illustratorID（テーブルユニークID）

+ Request
    + Headers
          Authorization: Bearer eyJ0eXAiOi...
          Content-Type: application/json

- Response 200 (application/json)
    - Attributes
        - id: 12000 (number)
        - name: 名前テキスト (string)
        - description: 詳細テキスト (string)
        + publish_status: 1 (number)
        - created_at: `2018-11-08 16:39:55` (string)
        - updated_at: `2018-11-08 16:39:55` (string)
        - deleted_at: null (string)

## illustrator登録 [/api/v1/illustrators]
### illustrator登録 [POST]
### 処理概要

- illustratorを1件新規登録する。
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

- Request (application/json)
    + Headers
          Authorization: Bearer eyJ0eXAiOi...
    - Attributes
        - name: `名前テキスト` (string)
        - description: `詳細テキスト` (string)
        + publish_status: 1 (number)

- Response 201 (application/json)
    - Attributes
        - id: 12000 (number)
        - name: 名前テキスト (string)
        - description: 詳細テキスト (string)
        + publish_status: 1 (number)
        - created_at: `2018-11-08 16:39:55` (string)
        - updated_at: `2018-11-08 16:39:55` (string)
        - deleted_at: null (string)


## illustrator編集 [/api/v1/illustrators/{illustrator_id}]
### illustrator編集 [PUT]
### 処理概要

- illustratorを1件編集する。
- コード一覧
    - publish_status
        - 1: Publish
        - 2: Under examination
        - 3: Draft
        - 4: Private

+ Parameters
    + illustrator_id: 1 (number) - illustratorID（テーブルユニークID）

- Request (application/json)
    + Headers
          Authorization: Bearer eyJ0eXAiOi...
    - Attributes
        - name: `名前テキスト` (string)
        - description: `詳細テキスト` (string)
        - publish_status: 1 (number)

- Response 200 (application/json)
    - Attributes
        - id: 12000 (number)
        - name: 名前テキスト (string)
        - description: 詳細テキスト (string)
        + publish_status: 1 (number)
        - created_at: `2018-11-08 16:39:55` (string)
        - updated_at: `2018-11-08 16:39:55` (string)
        - deleted_at: null (string)
